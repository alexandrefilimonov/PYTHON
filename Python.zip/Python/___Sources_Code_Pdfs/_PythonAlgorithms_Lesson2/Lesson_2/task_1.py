while True:
    num = float(input('Число: '))
    if num > 100:
        break

