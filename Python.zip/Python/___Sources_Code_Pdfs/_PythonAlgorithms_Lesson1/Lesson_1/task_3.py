a = float(input('a = '))
b = float(input('b = '))
c = float(input('c = '))

if a > b:
    if a > c:
        print(f'максимум = {a:.3f}')
    else:
        print(f'максимум = {c:.3f}')
else:
    if b > c:
        print(f'максимум = {b:.3f}')
    else:
        print(f'максимум = {c:.3f}')
