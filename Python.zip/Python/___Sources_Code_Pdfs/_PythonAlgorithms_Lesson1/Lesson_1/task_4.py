# y = 2x-10, если x > 0
# y = 0, если x = 0
# y = 2*|x|-1, если x < 0
# x - целое число

x = int(input('Введите целое число: '))

if x > 0:
    y = 2 * x - 10
elif x == 0:
    y = 0
else:
    y = 2 * abs(x) - 1

print(f'y = {y}')
