a = float(input('a = '))
b = float(input('b = '))
c = float(input('c = '))

m = a

if m < b:
    m = b
if m < c:
    m = c

print(f'm = {m:.3f}')
