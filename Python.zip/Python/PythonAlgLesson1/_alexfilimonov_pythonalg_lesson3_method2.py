﻿n1 = 5
n2 = 6
bitAnd = n1 & n2
bitOr = n1 | n2
bitLeft2Difits = n1 << 2
bitRight2Difits = n1 >> 2 

print("Bit AND between 5 and 6 is ",bitAnd)
print("Bit AND between 5 and 6 is ",bitOr)
print("Bit shift left for 2 digits for 5 is ",bitLeft2Difits)
print("Bit shift right for 2 digits for 5 is ",bitRight2Difits)
