﻿#2. Каждое из слов «class», «function», «method» записать в байтовом типе без преобразования в последовательность 
#кодов (не используя методы encode и decode) и определить тип, содержимое и длину соответствующих переменных.

a= b'class'
b= b'function'
c= b'method'
print('Variable a has type - ',type(a),', content - ',a,' length - ', len(a)) 
print('Variable b has type - ',type(b),', content - ',b,' length - ', len(b)) 
print('Variable c has type - ',type(c),', content - ',c,' length - ', len(c)) 
